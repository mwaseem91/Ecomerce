
<?php $__env->startSection('contant'); ?>

   <table class="table">
       <thead>
           <tr>
               <th>S.No</th>
               <th>Product Name</th>
               <th>category Name</th>
               <th>Price</th>
               <th>Image</th>
               <th>Extra Detail</th>
               <th>Action</th>
           </tr>
       </thead>
       <tbody>
           <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                
                <td><?php echo e($product->name); ?></td>
                <td><?php if($product->category_id): ?>
                    <?php echo e($product->catagory->name); ?> 
                   
                    <?php endif; ?>
                    
                </td>
                <td><?php echo e($product->price); ?> </td>
                <td><img style="height:60px; width:80px;" src="<?php echo e(asset('upload/'.$product->image)); ?>"> </td>
                <td><button><a href="<?php echo e(route('ProductDetail.extraDetail',$product->id)); ?>">Add</a></button></td>
                
                <td> <a href="<?php echo e(route('products.edit',$product->id)); ?>" style="font-size:17px; padding:5px;"><li class="fa fa-edit"><li></a></td>
                <form action="<?php echo e(route('products.destroy',$product->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?> 
                <td> <button type="submit" class="btn btn-danger"><li class="fa fa-trash"><li></button></td>
                </form>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
   </table>  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecommerce\resources\views/admin/product/index.blade.php ENDPATH**/ ?>