
<?php $__env->startSection('contant'); ?>

   <table class="table">
       <thead>
           <tr>
               <th>S.No</th>
               <th>category Name</th>
               <th>Parent category Name</th>
               <th>Created Date</th>
               <th>Action</th>
           </tr>
       </thead>
       <tbody>
           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($categories->name); ?></td>
                <td>
                    <?php if($categories->category_id): ?>
                    <?php echo e($categories->Parent->name); ?></td>
                    <?php else: ?>
                    No Parent Category
                </td>
                <?php endif; ?>
                <td><?php echo e($categories->created_at); ?></td>
                <td> <a href="<?php echo e(route('category.edit',$categories->id)); ?>" style="font-size:17px; padding:5px;"><li class="fa fa-edit"><li></a></td>
                <td> <a href="<?php echo e(route('category.delete',$categories->id)); ?>" style="font-size:17px; padding:5px;"><li class="fa fa-trash"></li></a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
   </table>  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecommerce\resources\views/admin/category/index.blade.php ENDPATH**/ ?>