
<?php $__env->startSection('contant'); ?>

   <table class="table">
       <thead>
           <tr>
               <th>S.No</th>
               <th>Name</th>
               <th>Email</th>
               <th>Created Date</th>
               <th>Action</th>
           </tr>
       </thead>
       <tbody>
           <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->created_at); ?></td>
                <td> <a href="<?php echo e(route('admin.user.delete',$user->id)); ?>" style="font-size:17px; padding:5px;"><li class="fa fa-trash"></li></a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
   </table>  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecommerce\resources\views/admin/user/index.blade.php ENDPATH**/ ?>