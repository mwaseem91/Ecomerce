@extends('admin.layout.layout')
@section('contant')

   <table class="table">
       <thead>
           <tr>
               <th>S.No</th>
               <th>Name</th>
               <th>Email</th>
               <th>Created Date</th>
               <th>Action</th>
           </tr>
       </thead>
       <tbody>
           @foreach ($user as $key=>$user)
            <tr>
                <td>{{ $key + 1 }}</td>
                <td>{{ $user->name }}</td>
                <td>{{ $user->email }}</td>
                <td>{{ $user->created_at }}</td>
                <td> <a href="{{ route('admin.user.delete',$user->id) }}" style="font-size:17px; padding:5px;"><li class="fa fa-trash"></li></a></td>
            </tr>
        @endforeach
       </tbody>
   </table>  
@endsection

{{-- @push('footer-script')
    <script>
        $('.category_delete').on('click',function(){
            if(confirm('you are delete this category.'))
            {
                var id =$(this).data('id');
                $.ajax({
                    url:"{{ route('category.destroy') }}",
                    method: "POST",
                    data:{
                        _token:'{{ csrf_token() }}'
                        'id': id;
                    },
                    Success:function(data){
                        location.reload()
                    }

                })
            }
        });
    </script>
    
@endpush --}}